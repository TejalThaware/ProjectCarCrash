import React, { useState } from 'react';
import CrashList from './CrashList';
import CrashForm from './CrashForm';
import './styles.css'; // Import the new stylesheet

const App = () => {
    const [currentCrash, setCurrentCrash] = useState(null);
    const [showForm, setShowForm] = useState(false);

    const handleEdit = (crash) => {
        setCurrentCrash(crash);
        setShowForm(true);
    };

    const handleCloseForm = () => {
        setCurrentCrash(null);
        setShowForm(false);
    };

    return (
        <div className="container">
            <h1>Car Crash Records</h1>
            {showForm ? (
                <CrashForm currentCrash={currentCrash} onClose={handleCloseForm} />
            ) : (
                <>
                    <CrashList onEdit={handleEdit} />
                    <button className="add-crash" onClick={() => setShowForm(true)}>Add Crash</button>
                </>
            )}
        </div>
    );
};

export default App;
