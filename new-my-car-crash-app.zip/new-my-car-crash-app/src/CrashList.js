import React, { useEffect, useState } from 'react';
import { fetchCrashes, deleteCrash } from './api'; // No need to import updateCrash here
import CrashForm from './CrashForm';

const CrashList = () => {
    const [crashes, setCrashes] = useState([]);
    const [currentCrash, setCurrentCrash] = useState(null); // State to hold the crash being edited
    const [showForm, setShowForm] = useState(false);

    // Fetch all crashes when the component loads
    useEffect(() => {
        const getCrashes = async () => {
            const data = await fetchCrashes();
            setCrashes(data);
        };
        getCrashes();
    }, []);

    // Function to handle the delete operation
    const handleDelete = async (id) => {
        const confirmDelete = window.confirm(`Are you sure you want to delete crash ID ${id}?`);
        if (confirmDelete) {
            await deleteCrash(id); // Send DELETE request to the API
            setCrashes(crashes.filter(crash => crash['Crash id'] !== id));  // Remove from state
        }
    };

    // Function to handle crash editing (when the "Edit" button is clicked)
    const handleEdit = (crash) => {
        setCurrentCrash(crash);  // Set the crash to be edited
        setShowForm(true);  // Show the form
    };

    // Function to handle saving (both new and updated crashes)
    const handleSave = (savedCrash) => {
        setCrashes((prevCrashes) => {
            const existingCrashIndex = prevCrashes.findIndex(c => c['Crash id'] === savedCrash['Crash id']);
            if (existingCrashIndex !== -1) {
                // Update existing crash in the state
                const updatedCrashes = [...prevCrashes];
                updatedCrashes[existingCrashIndex] = savedCrash;
                return updatedCrashes;
            } else {
                // Add new crash to the state
                return [...prevCrashes, savedCrash];
            }
        });
        setShowForm(false);  // Close the form after saving
        setCurrentCrash(null);  // Clear current crash
    };

    return (
        <div>
            <h2>Car Crash Records</h2>
            {showForm ? (
                <CrashForm currentCrash={currentCrash} onClose={() => setShowForm(false)} onSave={handleSave} /> 
            ) : (
                <>
                    <ul>
                        {crashes.length > 0 ? (
                            crashes.map(crash => (
                                <li key={crash['Crash id']}>
                                    {crash['Crash id']} - {crash['Crash Location']} on {crash['Crash Date']}
                                    <button onClick={() => handleEdit(crash)}>Edit</button>
                                    <button onClick={() => handleDelete(crash['Crash id'])}>Delete</button>
                                </li>
                            ))
                        ) : (
                            <li>No crash records found.</li>
                        )}
                    </ul>
                    <button className="add-crash" onClick={() => setShowForm(true)}>Add Crash</button>
                </>
            )}
        </div>
    );
};

export default CrashList;
