import axios from 'axios';

// Base API URL
const API_URL = 'http://127.0.0.1:5000/crashes';

// Function to fetch all crashes
export const fetchCrashes = async () => {
    try {
        const response = await axios.get(API_URL);
        return response.data;
    } catch (error) {
        console.error('Error fetching crashes:', error);
        throw error; // Re-throw the error to handle it in the component
    }
};

// Function to fetch a crash by ID
export const fetchCrashById = async (id) => {
    try {
        const response = await axios.get(`${API_URL}/${id}`);
        return response.data;
    } catch (error) {
        console.error(`Error fetching crash with id ${id}:`, error);
        throw error;
    }
};

// Function to create a new crash
export const createCrash = async (newCrash) => {
    try {
        const response = await axios.post(API_URL, newCrash);
        return response.data;
    } catch (error) {
        console.error('Error creating crash:', error);
        throw error;
    }
};

// Function to update an existing crash by ID
export const updateCrash = async (id, updatedCrash) => {
    try {
        const response = await axios.put(`${API_URL}/${id}`, updatedCrash);  // PUT request
        return response.data;
    } catch (error) {
        console.error(`Error updating crash with id ${id}:`, error);
        throw error;
    }
};


// Function to delete a crash by ID
export const deleteCrash = async (id) => {
    try {
        await axios.delete(`${API_URL}/${id}`);
    } catch (error) {
        console.error(`Error deleting crash with id ${id}:`, error);
        throw error;
    }
};
