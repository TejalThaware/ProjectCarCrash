import React, { useState, useEffect } from 'react';
import { createCrash, updateCrash } from './api';

const CrashForm = ({ currentCrash, onClose, onSave }) => {
    const [id, setCrashId] = useState('');
    const [location, setLocation] = useState('');
    const [date, setDate] = useState('');

    // Pre-populate the form if we're editing an existing crash
    useEffect(() => {
        if (currentCrash) {
            setCrashId(currentCrash['Crash id']);
            setLocation(currentCrash['Crash Location']);
            setDate(currentCrash['Crash Date']);
        } else {
            // Reset form for new crash
            setCrashId('');
            setLocation('');
            setDate('');
        }
    }, [currentCrash]);

    // Function to handle form submission for both new crash and update
    const handleSubmit = async (e) => {
        e.preventDefault();
        const crashData = { 'Crash id': id, 'Crash Location': location, 'Crash Date': date };

        if (currentCrash) {
            // Call updateCrash if we're editing an existing crash
            await updateCrash(id, crashData);
        } else {
            // Call createCrash if we're adding a new crash
            await createCrash(crashData);
        }

        onSave(crashData);  // Call the onSave function to update the state in CrashList.js
        onClose();  // Close the form
    };

    return (
        <form onSubmit={handleSubmit}>
            <input
                type="text"
                value={id}
                onChange={(e) => setCrashId(e.target.value)}
                placeholder="Crash ID"
                disabled={!!currentCrash}  // Disable ID input when editing
                required
            />
            <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Crash Location"
                required
            />
            <input
                type="text"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                placeholder="Crash Date"
                required
            />
            <button type="submit">{currentCrash ? 'Update Crash' : 'Add Crash'}</button>
            <button type="button" onClick={onClose}>Cancel</button>
        </form>
    );
};

export default CrashForm;
